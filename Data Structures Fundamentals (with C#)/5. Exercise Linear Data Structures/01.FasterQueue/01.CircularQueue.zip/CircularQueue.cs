﻿namespace Problem01.CircularQueue
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class CircularQueue<T> : IAbstractQueue<T>
    {
        private T[] array;
        private int startIndex;
        private int endIndex;

        public CircularQueue(int capacity = 4)
        {
            this.array = new T[capacity];
        }
        public int Count { get; set; }

        public T Dequeue()
        {
            CheckIfEmpty();
            var oldStart = this.array[startIndex];
            startIndex = (startIndex + 1) % this.array.Length;
            Count--;
            return oldStart;
        }

        public void Enqueue(T item)
        {
            if (this.Count >= array.Length)
            {
                this.Grow();
            }
            this.array[endIndex] = item;
            this.endIndex = (this.endIndex + 1) % this.array.Length;
            Count++;
        }

        public T Peek()
        {
            CheckIfEmpty();
            return this.array[startIndex];
        }

        public T[] ToArray()
        {
            var newArray = new T[this.Count];

            for (int i = 0; i < newArray.Length; i++)
            {
                newArray[i] = this.array[(startIndex + i) % this.array.Length];
            }
            return newArray;
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int currentIndex = 0; currentIndex < this.Count; currentIndex++)
            {
                yield return this.array[(this.startIndex + currentIndex) % this.array.Length];
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();


        private void Grow()
        {
            this.array = this.CopyArray();
            this.startIndex = 0;
            this.endIndex = Count;
        }

        private T[] CopyArray()
        {
            var newArray = new T[this.array.Length * 2];
            for (int i = 0; i < this.Count; i++)
            {
                newArray[i] = array[(startIndex + i) % array.Length];
            }
            return newArray;
        }

        private void CheckIfEmpty()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}
