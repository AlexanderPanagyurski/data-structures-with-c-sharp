﻿namespace Tree
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Tree<T> : IAbstractTree<T>
    {
        private T value;
        private Tree<T> parent;
        private IList<Tree<T>> children;

        public Tree(T value)
        {
            this.value = value;
            this.children = new List<Tree<T>>();
        }

        public Tree(T value, params Tree<T>[] children)
            : this(value)
        {
            foreach (var child in children)
            {
                child.parent = this;
                this.children.Add(child);
            }
        }

        public void AddChild(T parentKey, Tree<T> child)
        {
            var parentNode = this.FindNodeWithBfs(parentKey);

            if (parentNode == null)
            {
                throw new ArgumentNullException();
            }

            parentNode.children.Add(child);
            child.parent = parentNode;
        }

        public IEnumerable<T> OrderBfs()
        {
            var result = new List<T>();
            var queue = new Queue<Tree<T>>();

            queue.Enqueue(this);

            while (queue.Count > 0)
            {
                var currentNode = queue.Dequeue();
                result.Add(currentNode.value);

                foreach (var child in currentNode.children)
                {
                    queue.Enqueue(child);
                }
            }

            return result;
        }

        public IEnumerable<T> OrderDfs()
        {
            //Stack<T> elements = new Stack<T>();
            //ExecuteDfsWithStack(this, elements);
            ICollection<T> elements = new List<T>();
            ExecuteRecursiveDfs(this, elements);
            return elements;
        }

        public void RemoveNode(T nodeKey)
        {
            var noteToDelete = FindNodeWithBfs(nodeKey);

            if (noteToDelete == null)
            {
                throw new ArgumentNullException();
            }
            if (noteToDelete.parent == null)
            {
                throw new ArgumentException();
            }

            var parentNode = noteToDelete.parent;
            parentNode.children.Remove(noteToDelete);
            noteToDelete.parent = null;
        }

        public void Swap(T firstKey, T secondKey)
        {
            var firstNode = FindNodeWithBfs(firstKey);
            var secondNode = FindNodeWithBfs(secondKey);

            if (firstNode == null || secondNode == null)
            {
                throw new ArgumentNullException();
            }

            var firstParent = firstNode.parent;
            var secondParent = secondNode.parent;

            if (firstParent == null || secondParent == null)
            {
                throw new ArgumentException();
            }
            
            var indexOFirstChild=firstParent.children.IndexOf(firstNode);
            var indexOfSecondChild = secondParent.children.IndexOf(secondNode);

            firstParent.children[indexOFirstChild] = secondNode;
            secondParent.children[indexOfSecondChild] = firstNode;
        }
        private Tree<T> FindNodeWithBfs(T parentKey)
        {
            var queue = new Queue<Tree<T>>();
            var result = new List<T>();

            queue.Enqueue(this);

            while (queue.Count > 0)
            {
                var subTree = queue.Dequeue();
                result.Add(subTree.value);

                if (subTree.value.Equals(parentKey))
                {
                    return subTree;
                }

                foreach (var child in subTree.children)
                {
                    queue.Enqueue(child);
                }
            }
            return null;
        }

        private void ExecuteDfsWithStack(Tree<T> subTree, Stack<T> elements)
        {
            var stack = new Stack<Tree<T>>();

            stack.Push(subTree);

            while (stack.Count > 0)
            {
                var node = stack.Pop();

                foreach (var child in node.children)
                {
                    stack.Push(child);
                }
                elements.Push(node.value);
            }
        }

        private void ExecuteRecursiveDfs(Tree<T> subTree, ICollection<T> elements)
        {
            foreach (var child in subTree.children)
            {
                ExecuteRecursiveDfs(child, elements);
            }
            elements.Add(subTree.value);
        }
    }
}
